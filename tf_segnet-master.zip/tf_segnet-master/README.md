# tf_segnet
requirement:
tensorflow==1.4.0,
keras,
cPickle,
hickle,
numpy,
cv2,
PIL
# Reference: https://github.com/tkuanlun350/Tensorflow-SegNet
