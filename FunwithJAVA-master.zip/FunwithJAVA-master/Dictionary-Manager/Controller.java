//Author: Clarence Guo
public class Controller {
	
    public static void main(String[] args) {
        DictionaryManagerMenu.DictionaryManagerRun();
    }
}